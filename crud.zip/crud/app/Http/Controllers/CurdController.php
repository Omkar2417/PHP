<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Curd;
class CurdController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $cruds = Curd::all();  
  
        return view('index', compact('cruds'));  
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'first_name'=>'required',
            'last_name'=>'required',
            'gender'=>'required',
            'qualifications'=>'required'
        ]);
        $crud=new Curd;
        $crud->first_name =  $request->get('first_name');  
        $crud->last_name = $request->get('last_name');  
        $crud->qualifications = $request->get('qualifications');  
        $crud->gender = $request->get('gender');  
        $crud->save();  
        echo "Record Inserted";
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $crud= Curd::find($id);  
        return view('edit', compact('crud'));  
    }




    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'first_name' => 'required',
            'last_name' => 'required',
            'gender' => 'required',
            'qualifications' => 'required',
        ]);
    
        // Find the record by id
        $crud = Curd::find($id);
        
        // Update the record with the new values
        $crud->first_name = $request->get('first_name');
        $crud->last_name = $request->get('last_name');
        $crud->gender = $request->get('gender');
        $crud->qualifications = $request->get('qualifications');
        
        // Save the updated record back to the database
        $crud->save();
        
        // Optionally, redirect back to the index page with a success message
        return redirect('/show')->with('success', 'Record updated successfully');
    }
    

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $crud=Curd::find($id);  
        $crud->delete();  
    }

}
