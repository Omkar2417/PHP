<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Styled Form</title>
</head>
<body>

<div class="login-box">
    <h2>User Form</h2>
    <form method="post" action="<?php echo e(route('users.store')); ?>">  
        <?php echo csrf_field(); ?>     
        <div class="user-box">      
        <label for="first_name">First Name:</label>  
            <input type="text" class="form-control" name="first_name" required/>
            
        </div>  
        <div class="user-box">   
        <label for="last_name">Last Name:</label>     
            <input type="text" class="form-control" name="last_name" required/>
           
        </div>  
        <div class="user-box">     
        <label for="gender">Gender:</label>   
            <input type="text" class="form-control" name="gender" required/>
            
        </div>  
        <div class="user-box"> 
        <label for="qualifications">Qualifications:</label>       
            <input type="text" class="form-control" name="qualifications" required/>
            
        </div>  
        <button type="submit" class="btn-btn">Insert</button>  
    </form>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\crud\resources\views/create.blade.php ENDPATH**/ ?>