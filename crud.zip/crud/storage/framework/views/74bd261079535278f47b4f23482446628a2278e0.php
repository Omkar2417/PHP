<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
</head>

<body>
    <table border='1'>
        <thead>
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Gender</th>
                <th>Qualifications</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $cruds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($crud->id); ?></td>
                <td><?php echo e($crud->first_name); ?></td>
                <td><?php echo e($crud->last_name); ?></td>
                <td><?php echo e($crud->gender); ?></td>
                <td><?php echo e($crud->qualifications); ?></td>
                <td>
                    <form action="<?php echo e(route('users.destroy', $crud->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit">Delete</button>
                    </form>
                    <a href="<?php echo e(route('users.edit', $crud->id)); ?>">
    <button type="button">Edit</button>
</a>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\crud\resources\views/index.blade.php ENDPATH**/ ?>