<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Form</title>
    
</head>
<body>

<div class="login-box">
    <h2>Update User</h2>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <form action="<?php echo e(route('users.update',$crud->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        
        <div class="user-box">      
        <label for="first_name">First Name:</label>  
            <input type="text" class="form-control" name="first_name" value="<?php echo e($crud->first_name); ?>" required/>
            
        </div>  
      
        <div class="user-box">     
        <label for="last_name">Last Name:</label>   
            <input type="text" class="form-control" name="last_name" value="<?php echo e($crud->last_name); ?>" required/>
            
        </div>  
      
        <div class="user-box">  
        <label for="gender">Gender:</label>     
            <input type="text" class="form-control" name="gender" value="<?php echo e($crud->gender); ?>" required/>
             
        </div>  
      
        <div class="user-box">   
        <label for="qualifications">Qualifications:</label>    
            <input type="text" class="form-control" name="qualifications" value="<?php echo e($crud->qualifications); ?>" required/>
            
        </div>

        <button type="submit" class="btn-btn">Update</button>  
    </form>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\crud\resources\views/edit.blade.php ENDPATH**/ ?>